package com.sqs.training;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.Assert.*;


/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }




}
